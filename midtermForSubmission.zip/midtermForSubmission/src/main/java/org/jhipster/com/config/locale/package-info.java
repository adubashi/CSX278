/**
 * Locale specific code.
 */
package org.jhipster.com.config.locale;
