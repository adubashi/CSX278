/**
 * Data Transfer Objects.
 */
package org.jhipster.com.service.dto;
